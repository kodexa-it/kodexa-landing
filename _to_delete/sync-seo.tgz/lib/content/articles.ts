export type Article = {
  slug: string
  title: string
  description: string
  date: string
  readingTime: string
  ogImage: string
  storyImage: string
}

// URL y archivos heredados de kodexa.ar: no cambian para conservar el SEO del artículo.
export const articles: Article[] = [
  {
    slug: "de-los-requerimientos-a-una-solucion-digital-a-medida",
    title: "De los requerimientos a una solución digital a medida",
    description: "Del relevamiento al diseño y desarrollo de una web institucional a medida para una empresa de residuos: un proyecto en curso, contado con transparencia.",
    date: "2026-10-28",
    readingTime: "5 min",
    ogImage: "/recursos/de-los-requerimientos-a-una-solucion-og.png",
    storyImage: "/recursos/de-los-requerimientos-a-una-solucion-story.png",
  },
  {
    slug: "que-aprendimos-construyendo-un-saas-desde-cero",
    title: "Qué aprendimos construyendo un SaaS desde cero",
    description: "Cómo construimos Nexo, nuestro SaaS con IA: decisiones de producto, arquitectura y pagos, y lo que aprendimos en el camino. Un vistazo detrás de escena.",
    date: "2026-09-08",
    readingTime: "9 min",
    ogImage: "/recursos/que-aprendimos-construyendo-un-saas-og.png",
    storyImage: "/recursos/que-aprendimos-construyendo-un-saas-story.png",
  },
]

export const getArticle = (list: Article[], slug: string) => {
  const a = list.find((x) => x.slug === slug)
  if (!a) throw new Error(`Artículo desconocido: ${slug}`)
  return a
}
